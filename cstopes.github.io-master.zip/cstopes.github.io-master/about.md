---
layout: page
title: About
permalink: /about/
---
<html>
<body>
<p>Hi, my name is Cormac Stopes. I am a transition year student at Newbridge College, who has created this website as part of my final transition year portfolio.</p>
<p>I decided to make my TY portfolio a website because I have been practicing coding as part of transition year, and I wanted to put my skills to the test. Building the website was very challenging, but I think I have done a good job.</p>
<p>I hope you enjoy!</p>
</body>
</html>
